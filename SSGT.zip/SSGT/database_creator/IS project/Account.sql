create table Account 
(
	username	varchar(120)	not null,
    password	varchar(120)	not null,
    tipo		varchar(100)	not null,
    primary key(username)
)